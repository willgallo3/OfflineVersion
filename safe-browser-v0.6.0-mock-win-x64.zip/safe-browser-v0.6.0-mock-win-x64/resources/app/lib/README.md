[bg folder](./bg): shared code for the background process

[fg folder](./fg): shared code for the frontend processes