export default {
  get: 'promise',
  set: 'promise'
}