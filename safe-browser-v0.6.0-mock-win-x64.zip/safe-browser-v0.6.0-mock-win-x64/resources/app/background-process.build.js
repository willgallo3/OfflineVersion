(function () {'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var electron = require('electron');
var log$1 = _interopDefault(require('loglevel'));
var path = _interopDefault(require('path'));
var fs = _interopDefault(require('fs-extra'));
var os = _interopDefault(require('os'));
var rpc = _interopDefault(require('pauls-electron-rpc'));
var emitStream = _interopDefault(require('emit-stream'));
var EventEmitter = _interopDefault(require('events'));
var fs$1 = _interopDefault(require('fs'));
var globalModules = require('global-modules');
var co = require('co');
var immutable = require('immutable');
var reduxActions = require('redux-actions');
var electronLocalshortcut = require('electron-localshortcut');
var electronLocalshortcut__default = _interopDefault(electronLocalshortcut);
var jetpack = _interopDefault(require('fs-jetpack'));
var url = _interopDefault(require('url'));
var unusedFilename = _interopDefault(require('unused-filename'));
var speedometer = _interopDefault(require('speedometer'));
var redux = require('redux');
var thunk = _interopDefault(require('redux-thunk'));
var createNodeLogger = _interopDefault(require('redux-node-logger'));
var promiseMiddleware = _interopDefault(require('redux-promise'));
var lodash = require('lodash');
var zerr = _interopDefault(require('zerr'));
var beakerSafePlugin = _interopDefault(require('beaker-plugin-safe-app'));

// TODO - pull appropriately from build

let env = process.env.NODE_ENV || 'production';

var env$1 = {
  name: env
};

const BUILD_FOLDER = path.resolve(__dirname, '../../resources/build/');
const APP_NAME = 'maidsafe-safebrowser';
const ICON_FILE = 'safeicon.png';

const registerProtocolHandlers = () => {

  if (env$1.name !== 'production') {
    return;
  }

  if (process.platform === 'win32') {
    var iconPath = path.join(process.resourcesPath, 'app.asar.unpacked', 'build', ICON_FILE);
    registerProtocolHandlerWin32('safe', 'URL:SAFE Network URL', iconPath, process.execPath);

    // dont add safe-auth for now as added via authenticator
    // registerProtocolHandlerWin32('safe-auth', 'URL:SAFE Network URL', iconPath, escapedExecPath )
  }

  if (process.platform === 'linux') {
    installLinuxDesktopFile();
    installLinuxDesktopIcon();
  }
};

function installLinuxDesktopFile() {
  const escapedExecPath = process.execPath.replace(/\s/g, '\\ ');
  const escapedExecDir = path.dirname(process.execPath).replace(/\s/g, '\\ ');

  var templatePath = `${BUILD_FOLDER}/${APP_NAME}.desktop`;

  var desktopFile = fs.readFileSync(templatePath, 'utf8');

  desktopFile = desktopFile.replace(/\$APP_PATH/g, escapedExecDir);
  desktopFile = desktopFile.replace(/\$EXEC_PATH/g, escapedExecPath);

  var desktopFilePathLocation = path.join(os.homedir(), '.local', 'share', 'applications');
  var desktopFilePath = path.join(desktopFilePathLocation, `${APP_NAME}.desktop`);

  fs.ensureDirSync(desktopFilePathLocation);
  fs.writeFileSync(desktopFilePath, desktopFile);
}

function installLinuxDesktopIcon() {
  var iconStaticPath = `${BUILD_FOLDER}/${ICON_FILE}`;

  var iconFile = fs.readFileSync(iconStaticPath);

  var iconFilePathLocation = path.join(os.homedir(), '.local', 'share', 'icons');
  var iconFilePath = path.join(iconFilePathLocation, ICON_FILE);
  fs.ensureDirSync(iconFilePathLocation);
  fs.writeFileSync(iconFilePath, iconFile);
}

/**
 * To add a protocol handler on Windows, the following keys must be added to the Windows
 * registry:
 *
 * HKEY_CLASSES_ROOT
 *   $PROTOCOL
 *     (Default) = "$NAME"
 *     URL Protocol = ""
 *     DefaultIcon
 *       (Default) = "$ICON"
 *     shell
 *       open
 *         command
 *           (Default) = "$COMMAND" "%1"
 *
 * Source: https://msdn.microsoft.com/en-us/library/aa767914.aspx
 *
 * However, the "HKEY_CLASSES_ROOT" key can only be written by the Administrator user.
 * So, we instead write to "HKEY_CURRENT_USER\Software\Classes", which is inherited by
 * "HKEY_CLASSES_ROOT" anyway, and can be written by unprivileged users.
 */

function registerProtocolHandlerWin32(protocol, name, icon, command) {
  var Registry = require('winreg');

  var protocolKey = new Registry({
    hive: Registry.HKCU, // HKEY_CURRENT_USER
    key: '\\Software\\Classes\\' + protocol
  });
  protocolKey.set('', Registry.REG_SZ, name, callback);
  protocolKey.set('URL Protocol', Registry.REG_SZ, '', callback);

  var iconKey = new Registry({
    hive: Registry.HKCU,
    key: '\\Software\\Classes\\' + protocol + '\\DefaultIcon'
  });
  iconKey.set('', Registry.REG_SZ, icon, callback);

  var commandKey = new Registry({
    hive: Registry.HKCU,
    key: '\\Software\\Classes\\' + protocol + '\\shell\\open\\command'
  });
  commandKey.set('', Registry.REG_SZ, '"' + command + '" "%1"', callback);

  function callback(err) {
    if (err) log.error(err.message || err);
  }
}

let targetContents;

/**
 * On window initialisation we need to specify the webContents we're targetting for later
 * @param {[type]} webContents [description]
 */
function setRenderLoggerTarget(webContents) {
  targetContents = webContents;
}

/**
 * Set the target webcontents to log to
 * @param  {[type]} args [description]
 * @return {[type]}      [description]
 */
function logInRenderer(...args) {
  let target = targetContents || electron.webContents.getFocusedWebContents();
  if (!target) {
    return;
  }

  target.send('command', 'log', ...args);
}

var beakerBrowser = {
  eventsStream: 'readable',
  getInfo: 'promise',
  checkForUpdates: 'promise',
  restartBrowser: 'sync',
  reauthenticateSAFE: 'promise',

  getSettings: 'promise',
  getSetting: 'promise',
  setSetting: 'promise',

  listPlugins: 'promise',
  lookupPlugin: 'promise',
  installPlugin: 'promise',
  uninstallPlugin: 'promise',

  getHomePages: 'promise',
  getProtocolDescription: 'sync',

  getDefaultProtocolSettings: 'promise',
  setAsDefaultProtocolClient: 'promise',
  removeAsDefaultProtocolClient: 'promise'
};

// import { auth } from 'safe-js'

const UPDATE_SETTINGS = 'UPDATE_SETTINGS';

const { updateSettings } = reduxActions.createActions(UPDATE_SETTINGS);

const initialState = immutable.Map({
  auto_update_enabled: 0,
  authMessage: 'Not attempted to connect yet'
});

function settings(state = initialState, action) {
  let payload = immutable.fromJS(action.payload);

  switch (action.type) {
    case UPDATE_SETTINGS:
      {
        return state.mergeDeep(payload);
      }
      return;
    default:
      return state;
  }
}

function set(key, value) {
  return new Promise((resolve, reject) => {
    // let setter = {}
    // setter[key] = value
    // store.dispatch( updateSettings( setter ) )
    resolve();
  });
}

function get(key) {
  return new Promise((resolve, reject) => {
    // let settings = store.getState()[ 'settings' ]

    // if( settings )
    // {
    // 	let result = settings.get( key )
    // 	if( result )
    // 	{
    // 		resolve( settings.get( key ) )
    // 	}

    // }
    // else {
    resolve('undefined');
    // }
  });
}

function reauthenticateSAFE$1() {

  return;
  // auth.authorise( safeBrowserApp ).then( tok =>
  // {
  // 	store.dispatch( updateSettings( { 'authSuccess': true } ) )

  // 	store.dispatch( updateSettings( { 'authToken' : tok.token } ) )
  // 	store.dispatch( updateSettings( { 'authMessage': 'Authorised with SAFE Launcher' } ) )

  // } )
  // .catch( handleAuthError )
}

function getAll() {
  return new Promise((resolve, reject) => {
    // let settings = store.getState()[ 'settings' ]

    // if( settings )
    // {
    // 	resolve( settings.toJS() )
    // }
    // else {
    resolve({});
    // }
  });
}

// globals
// =
const WITH_CALLBACK_TYPE_PREFIX = '_with_cb_';
const WITH_ASYNC_CALLBACK_TYPE_PREFIX = '_with_async_cb_';

const PLUGIN_NODE_MODULES = path.join(__dirname, 'node_modules');
log$1.debug('[PLUGINS] Loading from', PLUGIN_NODE_MODULES);

// find all modules named beaker-plugin-*
var protocolModuleNames = [];
try {
  protocolModuleNames = fs$1.readdirSync(PLUGIN_NODE_MODULES).filter(name => name.startsWith('beaker-plugin-'));
} catch (e) {}

// load the plugin modules
var protocolModules = [];
var protocolPackageJsons = {};
protocolModuleNames.forEach(name => {
  // load module
  try {
    protocolModules.push(require(path.join(PLUGIN_NODE_MODULES, name)));
  } catch (e) {
    log$1.error('[PLUGINS] Failed to load plugin', name, e);
    return;
  }

  // load package.json
  loadPackageJson(name);
});

// exported api
// =

// fetch a complete listing of the plugin info
// - each plugin module can export arrays of values. this is a helper to create 1 list of all of them
var caches = {};
function getAllInfo(key) {
  // use cached
  if (caches[key]) return caches[key];

  // construct
  caches[key] = [];

  protocolModules.forEach(protocolModule => {
    if (!protocolModule[key]) return;
    // get the values from the module
    var values = protocolModule[key];

    if (!Array.isArray(values)) values = [values];

    if (key === 'webAPIs') {
      values = values.map(val => {
        if (typeof val === 'object' && !val.scheme) {
          if (Array.isArray(protocolModule.protocols) && protocolModule.protocols.length == 1) {
            val['scheme'] = protocolModule.protocols[0].scheme; // FIXME: for more than one scheme within plugin
          } else {
            val['schemes'] = protocolModule.protocols.map(proto => proto.scheme);
          }
        }
        return val;
      });
    }

    // add to list
    caches[key] = caches[key].concat(values);
  });
  return caches[key];
}

// register the protocols that have standard-url behaviors
// - must be called before app 'ready'
function registerStandardSchemes() {
  var protos = getAllInfo('protocols');

  // get the protocols that are 'standard'
  var standardSchemes = protos.filter(desc => desc.isStandardURL).map(desc => desc.scheme);

  // register
  electron.protocol.registerStandardSchemes(standardSchemes);
}

// register all protocol handlers
function setupProtocolHandlers() {
  getAllInfo('protocols').forEach(proto => {
    // run the module's protocol setup
    // log.debug('Registering protocol handler:', proto.scheme)
    proto.register();
  });
}

// setup all web APIs
function setupWebAPIs() {
  getAllInfo('webAPIs').forEach(api => {
    // run the module's protocol setup
    // log.debug('Wiring up Web API:', api.name, api.scheme)

    // We export functions with callbacks in a separate channel
    // since they will be adapted to invoke the callbacks
    let fnsToExport = [];
    let fnsWithCallbacks = [];
    let fnsWithAsyncCallbacks = [];
    for (var fn in api.manifest) {
      if (fn.startsWith(WITH_CALLBACK_TYPE_PREFIX)) {
        fnsWithCallbacks[fn] = api.manifest[fn];
      } else if (fn.startsWith(WITH_ASYNC_CALLBACK_TYPE_PREFIX)) {
        fnsWithAsyncCallbacks[fn] = api.manifest[fn];
      } else {
        fnsToExport[fn] = api.manifest[fn];
      }
    }
    rpc.exportAPI(api.name, fnsToExport, api.methods);
    rpc.exportAPI(WITH_CALLBACK_TYPE_PREFIX + api.name, fnsWithCallbacks, api.methods); // FIXME: api.methods shall be probably chopped too
    rpc.exportAPI(WITH_ASYNC_CALLBACK_TYPE_PREFIX + api.name, fnsWithAsyncCallbacks, api.methods); // FIXME: api.methods shall be probably chopped too
  });
}

// get web API manifests for the given protocol
function getWebAPIManifests(scheme) {
  var manifests = {};
  // massage input
  scheme = scheme.replace(/:/g, '');

  // get the protocol description
  var proto = getAllInfo('protocols').find(proto => proto.scheme == scheme);

  if (!proto) return manifests;

  // collect manifests
  getAllInfo('webAPIs').forEach(api => {
    // just need to match isInternal for the api and the scheme
    if (api.isInternal == proto.isInternal && (api.scheme === scheme || api.schemes && api.schemes.includes(scheme))) {
      manifests[api.name] = api.manifest;
    }
  });
  return manifests;
}

// internal methods
// =

function loadPackageJson(name) {
  var packageJson;
  try {
    packageJson = extractPackageJsonAttrs(require(path.join(PLUGIN_NODE_MODULES, name, 'package.json')));
  } catch (e) {
    packageJson = { name: name, status: 'installed' };
  }
  protocolPackageJsons[name] = packageJson;
}

function extractPackageJsonAttrs(packageJson) {
  return {
    name: packageJson.name,
    author: packageJson.author,
    description: packageJson.description,
    homepage: packageJson.homepage,
    version: packageJson.version,
    status: 'installed'
  };
}

// constants
// =

// how long between scheduled auto updates?
const SCHEDULED_AUTO_UPDATE_DELAY = 24 * 60 * 60 * 1e3; // once a day

// possible updater states
const UPDATER_STATUS_IDLE = 'idle';
const UPDATER_STATUS_CHECKING = 'checking';
const UPDATER_STATUS_DOWNLOADING = 'downloading';
const UPDATER_STATUS_DOWNLOADED = 'downloaded';

// globals
// =

// what's the updater doing?
var updaterState = UPDATER_STATUS_IDLE;
var updaterError = false; // has there been an error?

// is the updater available? must be on certain platform, and may be disabled if there's an error
var isBrowserUpdatesSupported = os.platform() == 'darwin' || os.platform() == 'win32';

// events emitted to rpc clients
var browserEvents = new EventEmitter();

// exported methods
// =

function setup() {
  // setup auto-updater
  try {
    if (!isBrowserUpdatesSupported) throw new Error('Disabled. Only available on macOS and Windows.');
    electron.autoUpdater.setFeedURL(getAutoUpdaterFeedURL());
    electron.autoUpdater.once('update-available', onUpdateAvailable);
    electron.autoUpdater.on('error', onUpdateError);
  } catch (e) {
    log$1.error('[AUTO-UPDATE]', e.toString());
    isBrowserUpdatesSupported = false;
  }
  setTimeout(scheduledAutoUpdate, 15e3); // wait 15s for first run

  // wire up RPC
  rpc.exportAPI('beakerBrowser', beakerBrowser, {
    eventsStream,
    getInfo,
    checkForUpdates,
    restartBrowser,
    reauthenticateSAFE,
    getSetting,
    getSettings,
    setSetting,

    getProtocolDescription,
    getHomePages,

    getDefaultProtocolSettings,
    setAsDefaultProtocolClient,
    removeAsDefaultProtocolClient
  });
}

function getDefaultProtocolSettings() {
  return Promise.resolve(['http', 'dat', 'ipfs', 'view-dat'].reduce((res, x) => {
    res[x] = electron.app.isDefaultProtocolClient(x);
    return res;
  }, {}));
}

function setAsDefaultProtocolClient(protocol) {
  return Promise.resolve(electron.app.setAsDefaultProtocolClient(protocol));
}

function removeAsDefaultProtocolClient(protocol) {
  return Promise.resolve(electron.app.removeAsDefaultProtocolClient(protocol));
}

function getInfo() {
  return Promise.resolve({
    version: electron.app.getVersion(),
    platform: os.platform(),
    updater: {
      isBrowserUpdatesSupported,
      error: updaterError,
      state: updaterState
    },
    paths: {
      userData: electron.app.getPath('userData')
    }
  });
}

// this method was written, as it is, when there was an in-app plugins installer
// since it works well enough, and the in-app installer may return, Im leaving it this way
// ... but, that would explain the somewhat odd design
// -prf
function checkForUpdates() {
  // dont overlap
  if (updaterState != UPDATER_STATUS_IDLE) return;

  // track result states for this run
  var isBrowserChecking = false; // still checking?
  var isBrowserUpdated = false; // got an update?

  // update global state
  log$1.debug('[AUTO-UPDATE] Checking for a new version.');
  updaterError = false;
  setUpdaterState(UPDATER_STATUS_CHECKING);

  if (isBrowserUpdatesSupported) {
    // check the browser auto-updater
    // - because we need to merge the electron auto-updater, and the npm plugin flow...
    //   ... it's best to set the result events here
    //   (see note above -- back when there WAS a plugin updater, this made since -prf)
    isBrowserChecking = true;
    electron.autoUpdater.checkForUpdates();
    electron.autoUpdater.once('update-not-available', () => {
      log$1.debug('[AUTO-UPDATE] No browser update available.');
      isBrowserChecking = false;
      checkDone();
    });
    electron.autoUpdater.once('update-downloaded', () => {
      log$1.debug('[AUTO-UPDATE] New browser version downloaded. Ready to install.');
      isBrowserChecking = false;
      isBrowserUpdated = true;
      checkDone();
    });

    // cleanup
    electron.autoUpdater.once('update-not-available', removeAutoUpdaterListeners);
    electron.autoUpdater.once('update-downloaded', removeAutoUpdaterListeners);
    function removeAutoUpdaterListeners() {
      electron.autoUpdater.removeAllListeners('update-not-available');
      electron.autoUpdater.removeAllListeners('update-downloaded');
    }
  }

  // check the result states and emit accordingly
  function checkDone() {
    if (isBrowserChecking) return; // still checking

    // done, emit based on result
    if (isBrowserUpdated) {
      setUpdaterState(UPDATER_STATUS_DOWNLOADED);
    } else {
      setUpdaterState(UPDATER_STATUS_IDLE);
    }
  }

  // just return a resolve; results will be emitted
  return Promise.resolve();
}

function restartBrowser() {
  if (updaterState == UPDATER_STATUS_DOWNLOADED) {
    // run the update installer
    electron.autoUpdater.quitAndInstall();
    log$1.debug('[AUTO-UPDATE] Quitting and installing.');
  } else {
    log$1.debug('Restarting Beaker by restartBrowser()');
    // do a simple restart
    electron.app.relaunch();
    setTimeout(() => electron.app.exit(0), 1e3);
  }
}

function getSetting(key) {
  return get(key);
}

function reauthenticateSAFE() {
  return reauthenticateSAFE$1();
}

function getSettings() {
  return getAll();
}

function setSetting(key, value) {
  return set(key, value);
}

// get the home-page listing
function getHomePages() {
  return Promise.resolve(getAllInfo('homePages'));
}

// get the description for a given scheme
function getProtocolDescription(scheme) {
  // massage input
  scheme = scheme.replace(/:/g, '');

  // find desc
  return getAllInfo('protocols').find(proto => proto.scheme == scheme);
}

// rpc methods
// =

function eventsStream() {
  return emitStream(browserEvents);
}

// internal methods
// =

function setUpdaterState(state) {
  updaterState = state;
  browserEvents.emit('updater-state-changed', state);
}

function getAutoUpdaterFeedURL() {
  if (os.platform() == 'darwin') {
    return 'https://download.beakerbrowser.net/update/osx/' + electron.app.getVersion();
  } else if (os.platform() == 'win32') {
    let bits = os.arch().indexOf('64') === -1 ? 32 : 64;
    return 'https://download.beakerbrowser.net/update/win' + bits + '/' + electron.app.getVersion();
  }
}

// run a daily check for new updates
function scheduledAutoUpdate() {
  get('auto_update_enabled').then(v => {
    // if auto updates are enabled, run the check
    if (+v === 1) checkForUpdates();

    // schedule next check
    setTimeout(scheduledAutoUpdate, SCHEDULED_AUTO_UPDATE_DELAY);
  });
}

// event handlers
// =

function onUpdateAvailable() {
  // update status and emit, so the frontend can update
  log$1.debug('[AUTO-UPDATE] New version available. Downloading...');
  setUpdaterState(UPDATER_STATUS_DOWNLOADING);
}

function onUpdateError(e) {
  log$1.error('[AUTO-UPDATE]', e.toString());
  setUpdaterState(UPDATER_STATUS_IDLE);
  updaterError = e.toString();
  browserEvents.emit('updater-error', e.toString());
}

var manifest = {
  add: 'promise',
  changeTitle: 'promise',
  changeUrl: 'promise',
  addVisit: 'promise',
  remove: 'promise',
  get: 'promise',
  list: 'promise'
};

var manifest$1 = {
  eventsStream: 'readable',
  getDownloads: 'promise',
  pause: 'promise',
  resume: 'promise',
  cancel: 'promise',
  remove: 'promise',
  open: 'promise',
  showInFolder: 'promise'
};

var manifest$2 = {
  addVisit: 'promise',
  getVisitHistory: 'promise',
  getMostVisited: 'promise',
  search: 'promise',
  removeVisit: 'promise',
  removeAllVisits: 'promise'
};

var manifest$3 = {
  get: 'promise',
  set: 'promise'
};

// dat-plugin is an optional internal dependency
var datPlugin;
try {
  datPlugin = require('beaker-plugin-dat');
} catch (e) {}

// exported api
// =

function setup$1() {
  // register a message-handler for setting up the client
  // - see lib/fg/import-web-apis.js
  electron.ipcMain.on('get-web-api-manifests', (event, scheme) => {
    // hardcode the beaker: scheme, since that's purely for internal use
    if (scheme == 'beaker:') {
      var protos = {
        beakerBrowser,
        beakerBookmarks: manifest,
        beakerDownloads: manifest$1,
        beakerHistory: manifest$2,
        beakerSitedata: manifest$3
      };
      if (datPlugin && datPlugin.webAPIs[0]) protos.datInternalAPI = datPlugin.webAPIs[0].manifest;
      event.returnValue = protos;
      return;
    }

    // for everything else, we'll use the plugins
    event.returnValue = getWebAPIManifests(scheme);
  });
}

// globals
// =

// downloads list
// - shared across all windows
var downloads = [];

// used for rpc
var downloadsEvents = new EventEmitter();

// exported api
// =

function setup$3() {
  // wire up RPC
  rpc.exportAPI('beakerDownloads', manifest$1, { eventsStream: eventsStream$1, getDownloads, pause, resume, cancel, remove, open, showInFolder });
}

function registerListener(win, opts = {}) {
  const listener = (e, item, webContents) => {
    // dont touch if already being handled
    // - if `opts.saveAs` is being used, there may be multiple active event handlers
    if (item.isHandled) return;

    // build a path to an unused name in the downloads folder
    const filePath = opts.saveAs ? opts.saveAs : unusedFilename.sync(path.join(electron.app.getPath('downloads'), item.getFilename()));

    // track as an active download
    item.id = '' + Date.now() + ('' + Math.random()); // pretty sure this is collision proof but replace if not -prf
    item.name = path.basename(filePath);
    item.setSavePath(filePath);
    item.isHandled = true;
    item.downloadSpeed = speedometer();
    downloads.push(item);
    downloadsEvents.emit('new-download', toJSON(item));

    // TODO: use mime type checking for file extension when no extension can be inferred
    // item.getMimeType()

    // update dock-icon progress bar
    var lastBytes = 0;
    item.on('updated', () => {
      var sumProgress = {
        receivedBytes: getSumReceivedBytes(),
        totalBytes: getSumTotalBytes()

        // track rate of download
      };item.downloadSpeed(item.getReceivedBytes() - lastBytes);
      lastBytes = item.getReceivedBytes();

      // emit
      downloadsEvents.emit('updated', toJSON(item));
      downloadsEvents.emit('sum-progress', sumProgress);
      win.setProgressBar(sumProgress.receivedBytes / sumProgress.totalBytes);
    });

    item.on('done', (e, state) => {
      downloadsEvents.emit('done', toJSON(item));

      // replace entry with a clone that captures the final state
      downloads.splice(downloads.indexOf(item), 1, capture(item));

      // reset progress bar when done
      if (isNoActiveDownloads() && !win.isDestroyed()) {
        win.setProgressBar(-1);
      }

      // inform users of error conditions
      if (state === 'interrupted') {
        electron.dialog.showErrorBox('Download error', `The download of ${item.getFilename()} was interrupted`);
      }

      if (state === 'completed') {
        // flash the dock on osx
        if (process.platform === 'darwin') {
          electron.app.dock.downloadFinished(filePath);
        }

        // optional, for one-time downloads
        if (opts.unregisterWhenDone) {
          webContents.session.removeListener('will-download', listener);
        }
      }
    });
  };

  win.webContents.session.prependListener('will-download', listener);
  win.on('close', () => win.webContents.session.removeListener('will-download', listener));
}

function download(win, url, opts) {
  // register for onetime use of the download system
  opts = Object.assign({}, opts, { unregisterWhenDone: true });
  registerListener(win, opts);
  win.webContents.downloadURL(url);
}

// rpc api
// =

function eventsStream$1() {
  return emitStream(downloadsEvents);
}

function getDownloads() {
  return Promise.resolve(downloads.map(toJSON));
}

function pause(id) {
  var download = downloads.find(d => d.id == id);
  if (download) download.pause();
  return Promise.resolve();
}

function resume(id) {
  var download = downloads.find(d => d.id == id);
  if (download) download.resume();
  return Promise.resolve();
}

function cancel(id) {
  var download = downloads.find(d => d.id == id);
  if (download) download.cancel();
  return Promise.resolve();
}

function remove(id) {
  var download = downloads.find(d => d.id == id);
  if (download && download.getState() != 'progressing') downloads.splice(downloads.indexOf(download), 1);
  return Promise.resolve();
}

function open(id) {
  return new Promise((resolve, reject) => {
    // find the download
    var download = downloads.find(d => d.id == id);
    if (!download || download.state != 'completed') return reject();

    // make sure the file is still there
    fs$1.stat(download.getSavePath(), err => {
      if (err) return reject();

      // open
      electron.shell.openItem(download.getSavePath());
      resolve();
    });
  });
}

function showInFolder(id) {
  return new Promise((resolve, reject) => {
    // find the download
    var download = downloads.find(d => d.id == id);
    if (!download || download.state != 'completed') return reject();

    // make sure the file is still there
    fs$1.stat(download.getSavePath(), err => {
      if (err) return reject();

      // open
      electron.shell.showItemInFolder(download.getSavePath());
      resolve();
    });
  });
}

// internal helpers
// =

// reduce down to attributes
function toJSON(item) {
  return {
    id: item.id,
    name: item.name,
    url: item.getURL(),
    state: item.getState(),
    isPaused: item.isPaused(),
    receivedBytes: item.getReceivedBytes(),
    totalBytes: item.getTotalBytes(),
    downloadSpeed: item.downloadSpeed()
  };
}

// create a capture of the final state of an item
function capture(item) {
  var savePath = item.getSavePath();
  var dlspeed = item.download;
  item = toJSON(item);
  item.getURL = () => item.url;
  item.getState = () => item.state;
  item.isPaused = () => false;
  item.getReceivedBytes = () => item.receivedBytes;
  item.getTotalBytes = () => item.totalBytes;
  item.getSavePath = () => savePath;
  item.downloadSpeed = () => dlspeed;
  return item;
}

// sum of received bytes
function getSumReceivedBytes() {
  return getActiveDownloads().reduce((acc, item) => acc + item.getReceivedBytes(), 0);
}

// sum of total bytes
function getSumTotalBytes() {
  return getActiveDownloads().reduce((acc, item) => acc + item.getTotalBytes(), 0);
}

function getActiveDownloads() {
  return downloads.filter(d => d.getState() == 'progressing');
}

// all downloads done?
function isNoActiveDownloads() {
  return getActiveDownloads().length === 0;
}

function log$2(...args) {
  if (env$1.name !== 'production') {
    console.log.apply(console, args);
  }
}

// globals
// =

var idCounter = 0;
var activeRequests = [];

// exported api
// =

function setup$4() {
  // wire up handlers
  electron.session.defaultSession.setPermissionRequestHandler(onPermissionRequestHandler);
  electron.ipcMain.on('permission-response', onPermissionResponseHandler);
}

function denyAllRequests(win) {
  // remove all requests in the window, denying as we go
  activeRequests = activeRequests.filter(req => {
    if (req.win === win) {
      log$2('Denying outstanding permission for closing window, req #' + req.id + ' for ' + req.permission);
      req.cb(false);
      return false;
    }
    return true;
  });
}

// event handlers
// =

function onPermissionRequestHandler(webContents, permission, cb) {
  // look up the containing window
  var win = electron.BrowserWindow.fromWebContents(webContents.hostWebContents);
  if (!win) return log$2('Warning: failed to find containing window of permission request, ' + permission);

  // if we're already tracking this kind of permission request, then bundle them
  var req = activeRequests.find(req => req.win === win && req.permission === permission);
  if (req) {
    var oldCb = req.cb;
    req.cb = decision => {
      oldCb(decision);cb(decision);
    };
  } else {
    // track the new cb
    var req = { id: ++idCounter, win, permission, cb };
    activeRequests.push(req);
  }

  // send message to create the UI
  win.webContents.send('command', 'perms:prompt', req.id, webContents.id, permission);
}

function onPermissionResponseHandler(e, reqId, decision) {
  var win = e.sender;

  // lookup the cb
  var req = activeRequests.find(req => req.id == reqId);
  if (!req) return log$2('Warning: failed to find permission request for response #' + reqId);

  // untrack
  activeRequests.splice(activeRequests.indexOf(req), 1);

  // hand down the decision
  var cb = req.cb;
  cb(decision);
}

const CONSTANTS = {
  DATE_FORMAT: 'h:MM-mmm dd',
  NET_STATUS_CONNECTED: 'Connected',
  STATE_KEY: 'browserState'

};

const APP_STATUS = {
  AUTHORISING: 'AUTHORISING',
  AUTHORISATION_FAILED: 'AUTHORISATION_FAILED',
  AUTHORISATION_DENIED: 'AUTHORISATION_DENIED',
  AUTHORISED: 'AUTHORISED',
  READING_CONFIG: 'READING_CONFIG',
  READY: 'READY'
};

const MESSAGES = {
  INITIALIZE: {
    AUTHORISE_APP: 'Authorising Application',
    CHECK_CONFIGURATION: 'Checking configuration'
  },
  AUTHORISATION_ERROR: 'Failed to authorise',
  AUTHORISATION_DENIED: 'The authorisation request was denied',
  CHECK_CONFIGURATION_ERROR: 'Failed to retrieve configuration'
};

var queue = [];
var commandReceiver;

function runQueue() {
  queue.forEach(url => commandReceiver.send('command', 'file:new-tab', url));
  queue.length = 0;
}

function setup$5() {
  electron.ipcMain.once('shell-window-ready', function (e) {
    commandReceiver = e.sender;
    runQueue();
  });
}

function unsetReceiver() {
  commandReceiver = null;
  return;
}

function updateReceiver(webContents) {
  commandReceiver = webContents;
  runQueue();
}

function open$1(url) {

  if (commandReceiver && commandReceiver !== null) {
    commandReceiver.send('command', 'file:new-tab', url);
  } else {
    queue.push(url);

    //osx only for the still open but all windows closed state
    if (process.platform === 'darwin' && global.macAllWindowsClosed) {
      if (url.startsWith('safe-')) {
        createShellWindow();
      }
    }
  }
}

const UPDATE_SITE_DATA = 'UPDATE_SITE_DATA';

const { updateSiteData } = reduxActions.createActions(UPDATE_SITE_DATA);

const initialState$1 = immutable.List([immutable.Map({
  id: 'https:duckduckgo.com',
  data: immutable.Map({
    favicon: `data:image/pngbase64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACkklEQVQ4T22SXUiTURjH/+ds2jTNPiTbXC1jbtAYaAh97cKBYlpWk+gDFhQUeOFFYBdCXqwQirqT6KKiDzTqIjIZpKG4YQsligLN3FzYcCWDPtaG7vuceN+Xzb3mA+fiff7P//c8530OwRoRtOn7QIhdJnHerx3wn11dTvITC7ZqJzjXcgIHAW4DRCvpPMiBDsLhACHB7QNzrVlfDhA4pl8E5yegUHpUpjokpt+tNRw4YxYQ8lw36FcLBSIg0FrtpDTVw1AwGdfXQFVvg6axDZSlETxT+x+IIrWPsYJunXOulbjqoawq1U9wQuuESra5ArsejstMIccFxD6+keUIZ+/no/795OsRwwAl5BEHfylUFN8bx8jbn7C3mURDdCmJ7z8iWNd5UA4AOc44PycAOMDDANkoVBTddSOFIiSTaeh15aKp/eoLdPlugkX+5EEkD/EfFgArEXE8gbl2D8KRGMo3rc8JoesnodKOoaRmGQs3NMj8VYga8a0ChOpPwXL5mrS8TBhsRpODhMdL8XtIHDQXxNsiv0KivBLmx2MSIBUCm63CvKMSLE6h2pkQT9i9QVClK3xprnZSsH4OxbMs1vjKm+vgbTGiUJ1EiSmGxGIhlj4XSaMjc5qB2sU1VqgMLgJYsq6yB26o1eI7gddWCx5flo0tTgd4QnGfVXxIM01GF2XozlB4xNV13cFgQR/OmzqRmv6ED8O9mDhQho7eBRGkYLAwip7dr70SQIipRmOUAIdA4AnvbcJT6zfEUnFQutL80q2A0NrCgWHziLdUukpeTDUYXcJncpvu/uyVo/0NO2zYWqxBdNKVDnRftIMo2wXdPOq1Zm0ygJAU/skWpWGIgzTI1gU++ivta7a6kc7P/wNyZ/k5PvUO0QAAAABJRU5ErkJggg==`
  })
})]);

function sitedata(state = initialState$1, action) {
  let payload = immutable.fromJS(action.payload);

  switch (action.type) {
    case UPDATE_SITE_DATA:
      {
        let index = state.findIndex(site => {

          return site.get('id') === payload.get('id');
        });

        if (index > -1) {
          let siteToMerge = state.get(index);
          let updatedSite = siteToMerge.mergeDeep(payload);

          return state.set(index, updatedSite);
        }

        return state.push(payload);
      }
      return;
    default:
      return state;
  }
}

function setup$6() {
  // wire up RPC
  rpc.exportAPI('beakerSitedata', manifest$3, { get: get$1, set: set$1 });
}

function set$1(url, key, value) {
  let origin = extractOrigin(url);
  let sitedata = { id: origin, data: {} };

  sitedata.data[key] = value;

  return new Promise((resolve, reject) => {
    return store.dispatch(updateSiteData(sitedata));
  });
}

function get$1(url, key) {
  var origin = extractOrigin(url);
  let sitedata = { id: origin, key: key };

  return new Promise((resolve, reject) => {
    let site = store.getState()['sitedata'].find(site => site.get('id') === origin);

    if (site) {
      let datum = site.get('data').get(key);
      resolve(datum);
    } else {
      resolve(undefined);
    }
  });
}

function extractOrigin(originURL) {
  var urlp = url.parse(originURL);
  if (!urlp || !urlp.host || !urlp.protocol) return;
  return urlp.protocol + urlp.host + (urlp.port || '');
}

const ACTION_TYPES = {
  // Initializer
  AUTHORISE_APP: 'AUTHORISE_APP',
  GET_CONFIG: 'GET_CONFIG',
  SAVE_CONFIG: 'SAVE_CONFIG',
  SAVE_CONFIG_AND_QUIT: 'SAVE_CONFIG_AND_QUIT',

  SET_INITIALIZER_TASK: 'SET_INITIALIZER_TASK',
  STORE_NEW_ACCOUNT: 'STORE_NEW_ACCOUNT',
  NET_STATUS_CHANGED: 'NET_STATUS_CHANGED',
  RECONNECT_APP: 'RECONNECT_APP',

  // history
  UPDATE_SITE: 'UPDATE_SITE',
  DELETE_SITE: 'DELETE_SITE',
  DELETE_ALL: 'DELETE_ALL',

  //bookmarks
  UPDATE_BOOKMARK: 'UPDATE_BOOKMARK',
  DELETE_BOOKMARK: 'DELETE_BOOKMARK'
};

var _extends$1 = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

const initialBookmarkState = [];

const { updateBookmark, deleteBookmark } = reduxActions.createActions(ACTION_TYPES.UPDATE_BOOKMARK, ACTION_TYPES.DELETE_BOOKMARK);

function bookmarks(state = initialBookmarkState, action) {
  let payload = action.payload;

  if (action.error) {
    return state;
  }

  switch (action.type) {
    case ACTION_TYPES.GET_CONFIG:
      {
        if (payload && payload.bookmarks) {
          const newBookmarks = payload.bookmarks;
          return _.uniqBy([...state, ...newBookmarks], 'url');
        }
        return state;
      }
    case ACTION_TYPES.UPDATE_BOOKMARK:
      {
        let newState = [...state];

        let index = state.findIndex(site => {
          return site.url === payload.url;
        });

        if (index > -1) {
          let siteToMerge = state[index];
          let updatedSite = _extends$1({}, siteToMerge, payload);

          if (payload.newUrl) {
            updatedSite.url = payload.newUrl;
          }

          if (payload.num_visits) {
            let newVisitCount = siteToMerge.num_visits || 0;
            newVisitCount++;
            updatedSite.num_visits = newVisitCount;
          }
          newState[index] = updatedSite;

          return newState;
        }

        if (payload.num_visits) {
          //what case is this?
          return newState;
        }

        newState.push(_extends$1({}, payload));
        return newState;
      }
    case ACTION_TYPES.DELETE_BOOKMARK:
      {
        let index = state.findIndex(site => site.url === payload.url);

        let newState = [...state];

        newState.splice(index, 1);
        return newState;
      }
    default:
      return state;
  }
}

function setup$7() {
  // wire up RPC
  rpc.exportAPI('beakerBookmarks', manifest, { add, changeTitle, changeUrl, addVisit, remove: remove$1, get: get$2, list });
}

function add(url, title) {
  return new Promise((resolve, reject) => {
    let bookmark = { url, title };
    return store.dispatch(updateBookmark(bookmark));
  });
}

function changeTitle(url, title) {
  return new Promise((resolve, reject) => {
    let bookmark = { url, title };

    return store.dispatch(updateBookmark(bookmark));
  });
}

function changeUrl(oldUrl, newUrl) {
  return new Promise((resolve, reject) => {
    let bookmark = {
      url: oldUrl,
      newUrl: newUrl };

    return store.dispatch(updateBookmark(bookmark));
  });
}

function addVisit(url) {

  let site = store.getState()['bookmarks'].find(site => site.url === url);
  if (site) {
    return new Promise((resolve, reject) => {
      let bookmark = { url, num_visits: 1 };

      return store.dispatch(updateBookmark(bookmark));
    });
  } else {
    return Promise.resolve();
  }
}

function remove$1(url) {

  return new Promise((resolve, reject) => {
    let bookmark = { url };

    return store.dispatch(deleteBookmark(bookmark));
  });
}

function get$2(url) {
  return new Promise((resolve, reject) => {
    let bookmarks = store.getState().bookmarks;
    let bookmarkedSite = bookmarks.find(site => site.url === url);
    if (bookmarkedSite) {
      resolve(bookmarkedSite);
    } else {
      resolve(undefined);
    }
  });
}

function list() {

  let sites = store.getState()['bookmarks'];
  return new Promise((resolve, reject) => resolve(sites));
}

var _extends$2 = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

const BadParam = zerr('BadParam', '% must be a %');
const InvalidCmd = zerr('InvalidCommand', '% is not a valid command');

const initialHistoryState = [];

const { updateSite, deleteSite, deleteAll } = reduxActions.createActions(ACTION_TYPES.UPDATE_SITE, ACTION_TYPES.DELETE_SITE, ACTION_TYPES.DELETE_ALL);

function history(state = initialHistoryState, action) {
  let payload = action.payload;

  if (action.error) {
    return state;
  }

  switch (action.type) {
    case ACTION_TYPES.GET_CONFIG:
      {
        if (payload && payload.history) {
          const newHistory = payload.history;

          //here we should probably combine the visits
          return _.uniqBy([...state, ...newHistory], 'url');
        }
        return state;
      }
    case ACTION_TYPES.UPDATE_SITE:
      {
        let newState = [...state];

        let index = state.findIndex(site => {
          return site.url === payload.url;
        });

        if (index > -1) {
          let siteToMerge = state[index];
          let updatedSite = _extends$2({}, siteToMerge, payload);
          let lastVisit = payload.last_visit;

          if (lastVisit && !updatedSite.visits.includes(lastVisit)) {
            updatedSite.visits.push(lastVisit);
          }

          updatedSite.last_visit = payload.last_visit;

          newState[index] = updatedSite;

          return newState;
        }

        payload.visits = [payload.last_visit];

        newState.push(payload);
        return newState;
      }
    case ACTION_TYPES.DELETE_SITE:
      {
        let index = state.findIndex(site => site.url === payload.url);

        let newState = [...state];

        newState.splice(index, 1);
        return newState;
      }

    case ACTION_TYPES.DELETE_ALL:
      {
        return [];
      }
    default:
      return state;
  }
}

function setup$8() {
  // wire up RPC
  rpc.exportAPI('beakerHistory', manifest$2, { addVisit: addVisit$1, getVisitHistory, getMostVisited, search, removeVisit, removeAllVisits });
}

function addVisit$1({ url, title }) {
  // each visit has a timestamp
  return new Promise((resolve, reject) => {
    if (url === 'safe-auth://home/#/login') // filters out `Safe Authenticator Home` entry
      {
        return;
      }
    let site = { url, title, last_visit: new Date() };
    if (site.url.length < 1) // filters out `about:blank` entry
      {
        return;
      }
    return store.dispatch(updateSite(site));
  });
}

function getVisitHistory({ offset, limit }) {

  return new Promise((resolve, reject) => {
    let history = store.getState()['history'];

    let filteredHistory = history.filter((value, key) => {
      return key >= offset && key <= limit;
    });

    if (filteredHistory) {
      resolve(filteredHistory);
    } else {
      resolve(undefined);
    }
  });
}

function getMostVisited({ offset, limit }) {

  offset = offset || 0;
  limit = limit || 50;

  return getVisitHistory({ offset, limit }).then(unsortedHistory => {
    unsortedHistory.sort(function (a, b) {
      return b.visits.length - a.visits.length; //high->low ??
    });

    return unsortedHistory;
  });
}

function search(q) {
  let history = store.getState()['history'];

  let filteredHistory = history.filter((value, key) => {
    return value.url.includes(q) || value.title.includes(q);
  });

  //sort mby most should be a helper function.
  filteredHistory = filteredHistory.sort(function (a, b) {
    if (!a.visits || !b.visits) {
      return 1;
    } else {
      return b.visits.length - a.visits.length; //high->low ??
    }
  });

  return new Promise((resolve, reject) => {
    resolve(filteredHistory);
  });
}

function removeVisit(url) {
  return new Promise((resolve, reject) => {
    let site = { url };

    return store.dispatch(deleteSite(site));
  });
}

function removeAllVisits() {

  return new Promise((resolve, reject) => {
    return store.dispatch(deleteAll());
  });
}

var _extends$3 = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

const initialState$2 = {
  appStatus: null,
  networkStatus: null,
  app: null,
  tasks: [],
  savedBeforeQuit: false
};

const initializer = (state = initialState$2, action) => {
  if (action.error) {
    logInRenderer('Error in initializer reducer: ', action, action.error);
    return state;
  }

  switch (action.type) {
    case ACTION_TYPES.SET_INITIALIZER_TASK:
      {
        const tasks = state.tasks.slice();
        tasks.push(action.task);
        return _extends$3({}, state, { tasks });
        break;
      }
    case `${ACTION_TYPES.AUTHORISE_APP}_LOADING`:
      return _extends$3({}, state, { app: null, appStatus: APP_STATUS.AUTHORISING });
      break;
    case ACTION_TYPES.AUTHORISE_APP:
      return _extends$3({}, state, {
        app: _extends$3({}, state.app, action.payload),
        appStatus: APP_STATUS.AUTHORISED,
        networkStatus: CONSTANTS.NET_STATUS_CONNECTED
      });
      break;
    case ACTION_TYPES.NET_STATUS_CHANGED:
      return _extends$3({}, state, { networkStatus: action.payload });
      break;
    case `${ACTION_TYPES.GET_CONFIG}`:
      return _extends$3({}, state, {
        appStatus: APP_STATUS.READY
      });
      break;
    default:
      return state;
      break;
  }
};

const rootReducer = redux.combineReducers({
  bookmarks,
  history,
  initializer,
  settings,
  sitedata
});

const allAPIs = beakerSafePlugin.webAPIs;

const WITH_CALLBACK_TYPE_PREFIX$1 = '_with_cb_';
const WITH_ASYNC_CALLBACK_TYPE_PREFIX$1 = '_with_async_cb_';

const getAPI = name => {
  const relevantApi = allAPIs.find(api => api.name === name);
  let methods = relevantApi.manifest;

  let newFnObject = {};
  Object.keys(methods).forEach(method => {
    let newName = method;
    if (method.startsWith(WITH_ASYNC_CALLBACK_TYPE_PREFIX$1)) {
      newName = method.replace(WITH_ASYNC_CALLBACK_TYPE_PREFIX$1, '');
    }
    if (method.startsWith(WITH_CALLBACK_TYPE_PREFIX$1)) {
      newName = method.replace(WITH_CALLBACK_TYPE_PREFIX$1, '');
    }

    newFnObject[newName] = relevantApi.methods[method];
  });

  return newFnObject;
};

var _extends$4 = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

const STATE_KEY = CONSTANTS.STATE_KEY;

const appInfo = {
  id: 'net.maidsafe.app.browser',
  name: 'SAFE Browser',
  vendor: 'MaidSafe.net Ltd',
  opts: {
    own_container: true
  },
  permissions: {}
};

let appObj = null;

const safeApp$1 = getAPI('safeApp');
const safeMutableData$1 = getAPI('safeMutableData');
const safeMutableDataEntries = getAPI('safeMutableDataEntries');
const safeMutableDataMutation = getAPI('safeMutableDataMutation');
const safeCrypto = getAPI('safeCrypto');
const safeCryptoPubEncKey = getAPI('safeCryptoPubEncKey');
const safeCryptoKeyPair = getAPI('safeCryptoKeyPair');
const safeCryptoSecEncKey = getAPI('safeCryptoSecEncKey');

// Has to hack via the datastream as that's actually returned by the func,
// not converted to promise as via the RPC.
const authoriseApp = () => {
  logInRenderer('Authorising app.');
  return new Promise((resolve, reject) => {
    appObj = {};
    let dataStream = safeApp$1.initialise(appInfo);

    dataStream.on('data', datum => {
      let handle = datum[0];
      appObj.handle = handle;

      safeApp$1.authorise(handle, appInfo.permissions, appInfo.opts).then(authUri => {
        appObj.authUri = authUri;
        return safeApp$1.connectAuthorised(handle, authUri).then(r => resolve(appObj));
      });
    });
  });
};

/**
 * Adds an encrypted value mutation to an existing mutation handle + key for a given MD.
 * Encrypts both the handle and the key.
 * @param  { String } md      mutableDataHandle
 * @param  { String } mut     mutationHandle
 * @param  { String } key     key to encrypt and store the value as
 * @param  { String } value   String or Buffer to encrypt and store
 * @param  { Int } version   [optional] version of the data if updating (then required)
 * @return { Promise }
 */
const updateOrCreateEncrypted = (mutableDataHandle, mutationHandle, key, value, version) => {
  let encryptedValue;

  return new Promise((resolve, reject) => {
    safeMutableData$1.encryptKey(mutableDataHandle, key).then(encryptedKey => safeMutableData$1.encryptValue(mutableDataHandle, value).then(res => {
      encryptedValue = res;

      if (version) {
        safeMutableDataMutation.update(mutationHandle, encryptedKey, encryptedValue, version).then(resolve);
      } else {
        safeMutableDataMutation.insert(mutationHandle, encryptedKey, encryptedValue).then(resolve);
      }
    })).catch(e => {
      logInRenderer('Problems updating/inserting encrypted: ', e, e.message);
      reject(e);
    });
  });
};

/**
 * Parses the browser state to json (removes initializer) and saves to an MD on the app Homecontainer,
 * encrypting as it goes.
 * @param  { Object } state App state
 * @param  { Bool } quit  to quit or not to quit...
 * @return {[type]}       Promise
 */
const saveConfigToSafe = (state, quit) => {
  const stateToSave = _extends$4({}, state, { initializer: {} });
  const JSONToSave = JSON.stringify(stateToSave);
  let encryptedData;
  let encryptedKey;
  let homeMdHandle;

  return new Promise((resolve, reject) => {
    const initializer = state.initializer;
    const app = initializer.app;

    if (!app || !app.handle || !app.authUri) {
      logInRenderer("Not authorised to save to the network.");
      console.log("Not authorised to save to the network.");

      if (quit) {
        electron.app.quit();
      }

      return reject('Not authorised to save data');
    }

    logInRenderer("Attempting to save state to the network.");

    safeApp$1.getOwnContainer(app.handle).then(res => homeMdHandle = res).then(data => encryptedData = data).then(() => {
      let mutationHandle;
      return safeMutableData$1.getEntries(homeMdHandle).then(entriesHandle => safeMutableDataEntries.mutate(entriesHandle)).then(res => mutationHandle = res).then(() => safeMutableData$1.encryptKey(homeMdHandle, STATE_KEY)).then(res => encryptedKey = res).then(() => safeMutableData$1.get(homeMdHandle, encryptedKey)).catch(e => logInRenderer(e.code, e.message)).then(value => {
        let version = null;

        if (value) {
          version = value.version + 1;
        }

        return updateOrCreateEncrypted(homeMdHandle, mutationHandle, STATE_KEY, JSONToSave, version);
      }).then(_ => safeMutableData$1.applyEntriesMutation(homeMdHandle, mutationHandle)).then(done => {
        logInRenderer("Successfully save data to the network.");
        resolve();

        if (quit) {
          electron.app.quit();
        }

        return Promise.resolve();
      });
    }).catch(e => {
      logInRenderer('Problems saving data to the network: ', e.message);
      reject(e);
      if (quit) {
        electron.app.quit();
      }
    });
  });
};

function delay(t) {
  return new Promise(function (resolve) {
    setTimeout(resolve, t);
  });
}

/**
 * Read the configuration from the netowrk
 * @param  {[type]} app SafeApp reference, with handle and authUri
 */
const readConfig = app => {
  return new Promise((resolve, reject) => {
    if (!app || !app.handle || !app.authUri) {
      reject('Not authorised to read from the network.');
    }

    let homeMdHandle;
    let encryptedKey;
    let encryptedValue;

    // FIXME: we add a delay here to prevent a deadlock known in the node-ffi
    // logic when dealing with the callbacks.
    // Research and remove this ASAP.
    return delay(5000).then(r => safeApp$1.getOwnContainer(app.handle)).then(res => homeMdHandle = res).then(() => safeMutableData$1.encryptKey(homeMdHandle, STATE_KEY)).then(res => encryptedKey = res).then(() => safeMutableData$1.get(homeMdHandle, encryptedKey)).then(res => encryptedValue = res).then(() => safeMutableData$1.decrypt(homeMdHandle, encryptedValue.buf)).then(browserState => JSON.parse(browserState.toString())).then(json => {
      logInRenderer("State retrieved: ", json);
      resolve(json);
    }).catch(e => {
      logInRenderer('Failure getting config from the network: ', e.message);
      logInRenderer('Failure getting config from the network: ', e.stack);
      reject(e);
    });
  });
};

const safeApp = getAPI('safeApp');
const safeMutableData = getAPI('safeMutableData');

const logger = createNodeLogger({
  level: 'info',
  collapsed: true
});

let enhancer = redux.compose(redux.applyMiddleware(thunk, promiseMiddleware));

let store = redux.createStore(rootReducer, enhancer);

const setInitializerTask = task => ({
  type: ACTION_TYPES.SET_INITIALIZER_TASK,
  task
});

const newNetStatusCallback = dispatch => {
  return function (state) {
    dispatch({
      type: ACTION_TYPES.NET_STATUS_CHANGED,
      payload: state
    });
  };
};

const authoriseApplication = () => {
  return function (dispatch) {
    return dispatch({
      type: ACTION_TYPES.AUTHORISE_APP,
      payload: new Promise((resolve, reject) => {
        authoriseApp().then(appObj => {
          resolve(appObj);
        }).catch(reject);
      })
    });
  };
};

const getConfig = () => {
  return function (dispatch, getState) {
    let app = getState().initializer.app;
    return dispatch({
      type: ACTION_TYPES.GET_CONFIG,
      payload: readConfig(app)
    });
  };
};

const saveConfig = () => {
  return function (dispatch, getState) {
    let state = getState();
    return dispatch({
      type: ACTION_TYPES.SAVE_CONFIG,
      payload: saveConfigToSafe(state)
    });
  };
};

const saveConfigAndQuit = () => {
  const quit = true;
  return function (dispatch, getState) {
    let state = getState();
    return dispatch({
      type: ACTION_TYPES.SAVE_CONFIG_AND_QUIT,
      payload: saveConfigToSafe(state, quit)
    });
  };
};

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

// globals
// =
var userDataDir;
var stateStoreFile = 'shell-window-state.json';
var numActiveWindows = 0;

global.browserStatus = { safeModeOn: true };

let authTargetContents;

//forward webview clicked events to current shell window
electron.ipcMain.on('webview-clicked', (event, response) => {
  let win = electron.BrowserWindow.getFocusedWindow();
  if (win && win.webContents) {
    win.webContents.send('webview-clicked');
  }
});

// exported methods
// =

function setup$2() {
  // config
  userDataDir = jetpack.cwd(electron.app.getPath('userData'));
  global.macAllWindowsClosed = false;

  // load pinned tabs
  electron.ipcMain.on('shell-window-ready', e => {
    // if this is the first window opened (since app start or since all windows closing)
    if (numActiveWindows === 1) {
      e.sender.webContents.send('command', 'load-pinned-tabs');

      updateReceiver(e.sender);

      //open devtools by defualt in dev
      // if( env.name !== 'production'  )
      // {
      //   BrowserWindow.getFocusedWindow().toggleDevTools()
      // }

      setRenderLoggerTarget(e.sender.webContents);
      authTargetContents = e.sender.webContents;

      store.dispatch(setInitializerTask(MESSAGES.INITIALIZE.AUTHORISE_APP));
      store.dispatch(authoriseApplication());
    }
  });

  // create first shell window
  return createShellWindow();
}

function createShellWindow() {

  global.macAllWindowsClosed = false;

  // create window
  var { x, y, width, height } = ensureVisibleOnSomeDisplay(restoreState());
  var win = new electron.BrowserWindow({
    titleBarStyle: 'hidden-inset',
    'standard-window': false,
    x, y, width, height,
    webPreferences: {
      webSecurity: false, // disable same-origin-policy in the shell window, webviews have it restored
      allowRunningInsecureContent: false
    }
  });

  //safe filter
  let filter = {
    urls: ['http://*/*', 'https://*/*']

  };

  const isLocal = requestDetails => {
    const parsedUrl = url.parse(requestDetails.url);
    return parsedUrl.hostname === 'localhost' || parsedUrl.hostname === '127.0.0.1';
  };

  win.webContents.session.webRequest.onBeforeSendHeaders(filter, (details, cb) => {
    let requestHeaders = _extends({}, details.requestHeaders);

    if (isLocal(details)) {
      //prevent localhost triggering CORS Accept-Origin + causing webview crash
      delete requestHeaders.Origin;
    }

    cb({ requestHeaders });
  });

  win.webContents.session.webRequest.onBeforeRequest(filter, (details, callback) => {
    if (!global.browserStatus.safeModeOn || isLocal(details)) {
      callback({});
    } else if (details.url.indexOf('http') > -1) {
      // FIXME shankar - temp handling for opening external links
      // if (details.url.indexOf('safe_proxy.pac') !== -1) {
      //   return callback({ cancel: true })
      // }
      try {
        electron.shell.openExternal(details.url);
      } catch (e) {};

      callback({ cancel: true, redirectURL: 'beaker:start' });
    }
  });

  //extra shortcuts outside of menus
  electronLocalshortcut__default.register(win, 'Alt+D', () => {
    if (win) win.webContents.send('command', 'file:open-location');
  });

  let prevState = store.getState();
  let unsubscribeFromStore = store.subscribe(() => {
    let newState = store.getState();
    logInRenderer(store.getState());

    win.webContents.send('safeStore-updated');

    if (prevState.initializer.appStatus !== APP_STATUS.AUTHORISED && newState.initializer.appStatus === APP_STATUS.AUTHORISED) {
      store.dispatch(getConfig());
    }

    prevState = newState;
  });

  global.windowStoreUnsubscribers[win.webContents.id] = unsubscribeFromStore;

  registerListener(win);
  loadURL(win, 'beaker:shell-window');
  numActiveWindows++;

  // register shortcuts
  for (var i = 1; i <= 9; i++) {
    electronLocalshortcut.register(win, 'CmdOrCtrl+' + i, onTabSelect(win, i - 1));
  }
  electronLocalshortcut.register(win, 'Ctrl+Tab', onNextTab(win));
  electronLocalshortcut.register(win, 'Ctrl+Shift+Tab', onPrevTab(win));

  // register event handlers
  win.on('scroll-touch-begin', sendToWebContents('scroll-touch-begin'));
  win.on('scroll-touch-end', sendToWebContents('scroll-touch-end'));
  win.on('focus', sendToWebContents('focus'));
  win.on('blur', sendToWebContents('blur'));
  win.on('enter-full-screen', sendToWebContents('enter-full-screen'));
  win.on('leave-full-screen', sendToWebContents('leave-full-screen'));
  win.on('close', onClose(win));

  return win;
}

// internal methods
// =

function loadURL(win, url) {
  win.loadURL(url);
  log$2('Opening', url);
}

function getCurrentPosition(win) {
  var position = win.getPosition();
  var size = win.getSize();
  return {
    x: position[0],
    y: position[1],
    width: size[0],
    height: size[1]
  };
}

function windowWithinBounds(windowState, bounds) {
  return windowState.x >= bounds.x && windowState.y >= bounds.y && windowState.x + windowState.width <= bounds.x + bounds.width && windowState.y + windowState.height <= bounds.y + bounds.height;
}

function restoreState() {
  var restoredState = {};
  try {
    restoredState = userDataDir.read(stateStoreFile, 'json');
  } catch (err) {
    // For some reason json can't be read (might be corrupted).
    // No worries, we have defaults.
  }
  return Object.assign({}, defaultState(), restoredState);
}

function defaultState() {
  var bounds = electron.screen.getPrimaryDisplay().bounds;
  var width = Math.max(800, Math.min(1800, bounds.width - 50));
  var height = Math.max(600, Math.min(1200, bounds.height - 50));
  return Object.assign({}, {
    x: (bounds.width - width) / 2,
    y: (bounds.height - height) / 2,
    width,
    height
  });
}

function ensureVisibleOnSomeDisplay(windowState) {
  var visible = electron.screen.getAllDisplays().some(display => windowWithinBounds(windowState, display.bounds));
  if (!visible) {
    // Window is partially or fully not visible now.
    // Reset it to safe defaults.
    return defaultState(windowState);
  }
  return windowState;
}

function onClose(win) {
  return e => {
    numActiveWindows--;

    // deny any outstanding permission requests
    denyAllRequests(win);

    // unregister shortcuts
    electronLocalshortcut.unregisterAll(win);

    // save state
    // NOTE this is called by .on('close')
    // if quitting multiple windows at once, the final saved state is unpredictable
    if (!win.isMinimized() && !win.isMaximized()) {
      var state = getCurrentPosition(win);
    }
  };
}

// shortcut event handlers
// =

function onTabSelect(win, tabIndex) {
  return () => win.webContents.send('command', 'set-tab', tabIndex);
}

function onNextTab(win) {
  return () => win.webContents.send('command', 'window:next-tab');
}
function onPrevTab(win) {
  return () => win.webContents.send('command', 'window:prev-tab');
}

// window event handlers
// =

function sendToWebContents(event) {
  return e => e.sender.webContents.send('window-event', event);
}

var darwinMenu = {
  label: 'SAFE Browser',
  submenu: [{ label: 'About the SAFE Browser', role: 'about' }, { type: 'separator' }, { label: 'Services', role: 'services', submenu: [] }, { type: 'separator' }, { label: 'Hide Beaker', accelerator: 'Command+H', role: 'hide' }, { label: 'Hide Others', accelerator: 'Command+Alt+H', role: 'hideothers' }, { label: 'Show All', role: 'unhide' }, { type: 'separator' }]
};

var fileMenu = {
  label: 'File',
  submenu: [{
    label: 'New Tab',
    accelerator: 'CmdOrCtrl+T',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'file:new-tab');
    }
  }, {
    label: 'New Window',
    accelerator: 'CmdOrCtrl+N',
    click: function () {
      createShellWindow();
    }
  }, {
    label: 'Reopen Closed Tab',
    accelerator: 'CmdOrCtrl+Shift+T',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'file:reopen-closed-tab');
    }
  }, {
    label: 'SAFE Browsing Enabled',
    checked: global.browserStatus.safeModeOn,
    accelerator: 'CmdOrCtrl+Shift+L',
    type: 'checkbox',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'window:toggle-safe-mode');
    }
  }, { type: 'separator' }, {
    label: 'Show SAFE Logs',
    click: function (item, win) {
      open$1('safe-logs:list');
    }
  }, { type: 'separator' }, { label: 'Save Browser State', accelerator: 'CmdOrCtrl+S', click() {
      store.dispatch(saveConfig());
    } }, { label: 'Save Browser State and Close', accelerator: 'Ctrl+Shift+Q', click() {
      store.dispatch(saveConfigAndQuit());
    } }, { label: 'Quit without saving', accelerator: 'CmdOrCtrl+Q', click() {
      electron.app.quit();
    } }, { type: 'separator' }, {
    label: 'Open File',
    accelerator: 'CmdOrCtrl+O',
    click: function (item, win) {
      if (win) {
        electron.dialog.showOpenDialog({ title: 'Open file...', properties: ['openFile', 'createDirectory'] }, files => {
          if (files && files[0]) win.webContents.send('command', 'file:new-tab', 'file://' + files[0]);
        });
      }
    }
  }, {
    label: 'Open Location',
    accelerator: 'CmdOrCtrl+L',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'file:open-location');
    }
  }, { type: 'separator' }, {
    label: 'Close Window',
    accelerator: 'CmdOrCtrl+Shift+W',
    click: function (item, win) {
      if (win) win.close();
    }
  }, {
    label: 'Close Tab',
    accelerator: 'CmdOrCtrl+W',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'file:close-tab');
    }
  }]
};

var editMenu = {
  label: 'Edit',
  submenu: [{ label: "Undo", accelerator: "CmdOrCtrl+Z", selector: "undo:" }, { label: "Redo", accelerator: "Shift+CmdOrCtrl+Z", selector: "redo:" }, { type: "separator" }, { label: "Cut", accelerator: "CmdOrCtrl+X", selector: "cut:" }, { label: "Copy", accelerator: "CmdOrCtrl+C", selector: "copy:" }, { label: "Paste", accelerator: "CmdOrCtrl+V", selector: "paste:" }, { label: "Select All", accelerator: "CmdOrCtrl+A", selector: "selectAll:" }, {
    label: "Find in Page",
    accelerator: "CmdOrCtrl+F",
    click: function (item, win) {
      if (win) win.webContents.send('command', 'edit:find');
    }
  }]
};

var viewMenu = {
  label: 'View',
  submenu: [{
    label: 'Reload',
    accelerator: 'CmdOrCtrl+R',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'view:reload');
    }
  }, {
    label: 'Hard Reload (Clear Cache)',
    accelerator: 'CmdOrCtrl+Shift+R',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'view:hard-reload');
    }
  }, { type: "separator" }, {
    label: 'Zoom In',
    accelerator: 'CmdOrCtrl+=',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'view:zoom-in');
    }
  }, {
    label: 'Zoom Out',
    accelerator: 'CmdOrCtrl+-',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'view:zoom-out');
    }
  }, {
    label: 'Actual Size',
    accelerator: 'CmdOrCtrl+0',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'view:zoom-reset');
    }
  }, { type: "separator" }, {
    label: 'Toggle DevTools',
    accelerator: 'Alt+CmdOrCtrl+I',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'view:toggle-dev-tools');
    }
  }]
};

var historyMenu = {
  label: 'History',
  role: 'history',
  submenu: [{
    label: 'Back',
    accelerator: 'CmdOrCtrl+Left',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'history:back');
    }
  }, {
    label: 'Forward',
    accelerator: 'CmdOrCtrl+Right',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'history:forward');
    }
  }]
};

var windowMenu = {
  label: 'Window',
  role: 'window',
  submenu: [{
    label: 'Minimize',
    accelerator: 'CmdOrCtrl+M',
    role: 'minimize'
  }, {
    label: 'Close',
    accelerator: 'CmdOrCtrl+Q',
    role: 'close'
  }, {
    label: 'Next Tab',
    accelerator: 'CmdOrCtrl+]',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'window:next-tab');
    }
  }, {
    label: 'Previous Tab',
    accelerator: 'CmdOrCtrl+[',
    click: function (item, win) {
      if (win) win.webContents.send('command', 'window:prev-tab');
    }
  }]
};
if (process.platform == 'darwin') {
  windowMenu.submenu.push({
    type: 'separator'
  });
  windowMenu.submenu.push({
    label: 'Bring All to Front',
    role: 'front'
  });
}

var devMenu = {
  label: 'Developer Tools',
  submenu: [{
    label: 'Reload Shell-Window',
    click: function () {
      electron.BrowserWindow.getFocusedWindow().webContents.reloadIgnoringCache();
    }
  }, {
    label: 'Toggle Shell-Window DevTools',
    accelerator: "CmdOrCtrl+Shift+I",
    click: function () {
      electron.BrowserWindow.getFocusedWindow().toggleDevTools();
    }
  }]
};

function buildWindowMenu(env) {
  var menus = [fileMenu, editMenu, viewMenu, historyMenu, windowMenu];
  if (process.platform === 'darwin') menus.unshift(darwinMenu);
  windowMenu.submenu.push({
    type: 'separator'
  });
  windowMenu.submenu.push(devMenu);
  return menus;
}

function registerContextMenu() {
  // register the context menu on every created webContents
  electron.app.on('web-contents-created', (e, webContents) => {
    webContents.on('context-menu', (e, props) => {
      var menuItems = [];
      const { mediaFlags, editFlags } = props;
      const hasText = props.selectionText.trim().length > 0;
      const can = type => editFlags[`can${type}`] && hasText;

      // get the focused window, ignore if not available (not in focus)
      // - fromWebContents(webContents) doesnt seem to work, maybe because webContents is often a webview?
      var targetWindow = electron.BrowserWindow.getFocusedWindow();
      if (!targetWindow) return;

      // ignore clicks on the shell window
      if (props.pageURL == 'beaker:shell-window') return;

      // helper to call code on the element under the cursor
      const callOnElement = js => {
        webContents.executeJavaScript(`
          var el = document.elementFromPoint(${props.x}, ${props.y})
          ${js}
        `);
      };

      // helper to run a download prompt for media
      const downloadPrompt = (item, win) => {
        var defaultPath = path.join(electron.app.getPath('downloads'), path.basename(props.srcURL));
        electron.dialog.showSaveDialog({ title: `Save ${props.mediaType} as...`, defaultPath }, filepath => {
          if (filepath) download(win, props.srcURL, { saveAs: filepath });
        });
      };

      // links
      if (props.linkURL && props.mediaType === 'none') {
        menuItems.push({ label: 'Open Link in New Tab', click: (item, win) => win.webContents.send('command', 'file:new-tab', props.linkURL) });
        menuItems.push({ label: 'Copy Link Address', click: () => electron.clipboard.writeText(props.linkURL) });
        menuItems.push({ type: 'separator' });
      }

      // images
      if (props.mediaType == 'image') {
        menuItems.push({ label: 'Save Image As...', click: downloadPrompt });
        menuItems.push({ label: 'Copy Image', click: () => webContents.copyImageAt(props.x, props.y) });
        menuItems.push({ label: 'Copy Image URL', click: () => electron.clipboard.writeText(props.srcURL) });
        menuItems.push({ label: 'Open Image in New Tab', click: (item, win) => win.webContents.send('command', 'file:new-tab', props.srcURL) });
        menuItems.push({ type: 'separator' });
      }

      // videos and audios
      if (props.mediaType == 'video' || props.mediaType == 'audio') {
        menuItems.push({ label: 'Loop', type: 'checkbox', checked: mediaFlags.isLooping, click: () => callOnElement('el.loop = !el.loop') });
        if (mediaFlags.hasAudio) menuItems.push({ label: 'Muted', type: 'checkbox', checked: mediaFlags.isMuted, click: () => callOnElement('el.muted = !el.muted') });
        if (mediaFlags.canToggleControls) menuItems.push({ label: 'Show Controls', type: 'checkbox', checked: mediaFlags.isControlsVisible, click: () => callOnElement('el.controls = !el.controls') });
        menuItems.push({ type: 'separator' });
      }

      // videos
      if (props.mediaType == 'video') {
        menuItems.push({ label: 'Save Video As...', click: downloadPrompt });
        menuItems.push({ label: 'Copy Video URL', click: () => electron.clipboard.writeText(props.srcURL) });
        menuItems.push({ label: 'Open Video in New Tab', click: (item, win) => win.webContents.send('command', 'file:new-tab', props.srcURL) });
        menuItems.push({ type: 'separator' });
      }

      // audios
      if (props.mediaType == 'audio') {
        menuItems.push({ label: 'Save Audio As...', click: downloadPrompt });
        menuItems.push({ label: 'Copy Audio URL', click: () => electron.clipboard.writeText(props.srcURL) });
        menuItems.push({ label: 'Open Audio in New Tab', click: (item, win) => win.webContents.send('command', 'file:new-tab', props.srcURL) });
        menuItems.push({ type: 'separator' });
      }

      // clipboard
      if (props.isEditable) {
        menuItems.push({ label: 'Cut', role: 'cut', enabled: can('Cut') });
        menuItems.push({ label: 'Copy', role: 'copy', enabled: can('Copy') });
        menuItems.push({ label: 'Paste', role: 'paste', enabled: editFlags.canPaste });
        menuItems.push({ type: 'separator' });
      } else if (hasText) {
        menuItems.push({ label: 'Copy', role: 'copy', enabled: can('Copy') });
        menuItems.push({ type: 'separator' });
      }

      // inspector
      menuItems.push({ label: 'Inspect Element', click: item => {
          webContents.inspectElement(props.x, props.y);
          if (webContents.isDevToolsOpened()) webContents.devToolsWebContents.focus();
        } });

      // protocol
      var urlp = url.parse(props.frameURL || props.pageURL);
      var pdesc = getProtocolDescription(urlp.protocol);
      if (pdesc && pdesc.contextMenu && Array.isArray(pdesc.contextMenu)) {
        menuItems.push({ type: 'separator' });
        pdesc.contextMenu.forEach(item => {
          menuItems.push({
            label: item.label,
            click: (_, win) => item.click(win, props)
          });
        });
      }

      // show menu
      var menu = electron.Menu.buildFromTemplate(menuItems);
      menu.popup(targetWindow);
    });
  });
}

function setup$9() {
  electron.protocol.registerFileProtocol('beaker', (request, cb) => {
    // FIXME
    // if-casing every possible asset is pretty dumb
    // generalize this
    // -prf

    // browser ui
    if (request.url == 'beaker:shell-window') return cb(path.join(__dirname, 'shell-window.html'));
    if (request.url == 'beaker:shell-window.js') return cb(path.join(__dirname, 'shell-window.build.js'));
    if (request.url == 'beaker:shell-window.css') return cb(path.join(__dirname, 'stylesheets/shell-window.css'));

    // builtin pages
    for (let slug of ['start', 'favourites', 'archives', 'history', 'downloads', 'settings']) {
      if (request.url == `beaker:${slug}`) return cb(path.join(__dirname, 'builtin-pages.html'));
    }
    if (request.url.startsWith('beaker:site/')) return cb(path.join(__dirname, 'builtin-pages.html'));
    if (request.url == 'beaker:builtin-pages.js') return cb(path.join(__dirname, 'builtin-pages.build.js'));
    if (request.url == 'beaker:builtin-pages.css') return cb(path.join(__dirname, 'stylesheets/builtin-pages.css'));

    // common assets
    if (request.url == 'beaker:font') return cb(path.join(__dirname, 'fonts/photon-entypo.woff'));
    if (request.url.startsWith('beaker:logo')) return cb(path.join(__dirname, 'img/logo.png'));
    if (request.url.startsWith('beaker:safe-auth-logo')) return cb(path.join(__dirname, 'img/safe_auth_logo.svg'));
    if (request.url.startsWith('beaker:safe-auth-nav-logo-dark')) return cb(path.join(__dirname, 'img/authenticator-logo-dark.svg'));
    if (request.url.startsWith('beaker:safe-auth-nav-logo-loading')) return cb(path.join(__dirname, 'img/authenticator_loading.gif'));
    if (request.url.startsWith('beaker:auth-popup-documents-icon')) return cb(path.join(__dirname, 'img/documents.svg'));
    if (request.url.startsWith('beaker:auth-popup-downloads-icon')) return cb(path.join(__dirname, 'img/downloads.svg'));
    if (request.url.startsWith('beaker:auth-popup-music-icon')) return cb(path.join(__dirname, 'img/music.svg'));
    if (request.url.startsWith('beaker:auth-popup-photos-icon')) return cb(path.join(__dirname, 'img/photos.svg'));
    if (request.url.startsWith('beaker:auth-popup-public-icon')) return cb(path.join(__dirname, 'img/public.svg'));
    if (request.url.startsWith('beaker:auth-popup-publicnames-icon')) return cb(path.join(__dirname, 'img/publicnames.svg'));
    if (request.url.startsWith('beaker:auth-popup-videos-icon')) return cb(path.join(__dirname, 'img/videos.svg'));
    if (request.url.startsWith('beaker:auth-popup-default-icon')) return cb(path.join(__dirname, 'img/default-container.svg'));
    if (request.url.startsWith('beaker:auth-popup-expand-arrow')) return cb(path.join(__dirname, 'img/expand_arrow.svg'));
    if (request.url.startsWith('beaker:auth-popup-toggle-info')) return cb(path.join(__dirname, 'img/toggle_info.svg'));
    if (request.url.startsWith('beaker:auth-popup-toggle-app')) return cb(path.join(__dirname, 'img/toggle_app.svg'));

    if (request.url.startsWith('beaker:safe-auth-nav-logo')) return cb(path.join(__dirname, 'img/authenticator-logo.svg'));
    if (request.url.startsWith('beaker:safe-auth-home')) return cb(electron.shell.openExternal('safe-auth://home/'));

    return cb(-6);
  }, e => {
    if (e) console.error('Failed to register beaker protocol', e);
  });
}

function setup$10() {
  // load default favicon
  var defaultFaviconBuffer = -6; // not found, till we load it
  fs$1.readFile(path.join(__dirname, './img/default-favicon.ico'), (err, buf) => {
    if (err) console.log('Failed to load default favicon', path.join(__dirname, '../../img/default-favicon.ico'), err);
    if (buf) defaultFaviconBuffer = buf;
  });

  // load logo favicon
  var logoBuffer = -6; // not found, till we load it
  fs$1.readFile(path.join(__dirname, './img/logo-favicon.png'), (err, buf) => {
    if (err) console.log('Failed to load logo favicon', path.join(__dirname, '../../img/logo.png'), err);
    if (buf) logoBuffer = buf;
  });

  // register favicon protocol
  electron.protocol.registerBufferProtocol('beaker-favicon', (request, cb) => {
    var url = request.url.slice('beaker-favicon:'.length);

    // special case
    if (url == 'beaker') return cb(logoBuffer);

    // look up in db
    get$1(url, 'favicon').then(data => {
      if (data) {
        // `data` is a data url ('data:image/png;base64,...')
        // so, skip the beginning and pull out the data
        data = data.split(',')[1];
        if (data) return cb(new Buffer(data, 'base64'));
      }
      cb(defaultFaviconBuffer);
    }).catch(err => cb(defaultFaviconBuffer));
  }, e => {
    if (e) console.error('Failed to register beaker-favicon protocol', e);
  });
}

var mainWindow = null;

const parseSafeUri = function (uri) {
  return uri.replace('//', '').replace('==/', '==');
};

global.windowStoreUnsubscribers = {};

// // configure logging
log$1.setLevel('trace');

// load the installed protocols
registerStandardSchemes();

electron.app.on('ready', function () {

  //init protocols
  registerProtocolHandlers();

  // API initialisations
  setup$6();
  setup$7();
  setup$8();

  // base
  setup();

  // ui
  electron.Menu.setApplicationMenu(electron.Menu.buildFromTemplate(buildWindowMenu(env$1)));
  registerContextMenu();
  setup$2();
  setup$3();
  setup$4();

  // protocols
  setup$9();
  setup$10();
  setupProtocolHandlers();

  // web APIs
  setup$1();
  setupWebAPIs();

  // listen OSX open-url event
  setup$5();

  if (process.platform === 'linux' || process.platform === 'win32') {
    if (process.argv[1] && process.argv[1].indexOf('safe') !== -1) {
      open$1(parseSafeUri(process.argv[1]));
    }
  }

  const shouldQuit = electron.app.makeSingleInstance(function (commandLine, workingDirectory) {
    if (commandLine.length >= 2 && commandLine[1]) {
      open$1(parseSafeUri(commandLine[1]));
    }

    mainWindow = electron.BrowserWindow.getFocusedWindow() || electron.BrowserWindow.getAllWindows()[0];

    // Someone tried to run a second instance, we should focus our window
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  if (shouldQuit) {
    electron.app.quit();
  }
});

electron.app.on('window-all-closed', function () {
  let allUnsubscribers = global.windowStoreUnsubscribers;

  Object.values(allUnsubscribers).forEach(unSubscriber => {
    unSubscriber();
  });

  // reset the obj
  global.windowStoreUnsubscribers = {};

  unsetReceiver();

  if (process.platform !== 'darwin') electron.app.quit();

  global.macAllWindowsClosed = true;
});

electron.app.on('open-url', function (e, url) {
  open$1(url);
});
}());
//# sourceMappingURL=background-process.build.js.map