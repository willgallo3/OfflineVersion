// TODO - pull appropriately from build

let env = process.env.NODE_ENV || 'production'

export default {
  name: env
}
